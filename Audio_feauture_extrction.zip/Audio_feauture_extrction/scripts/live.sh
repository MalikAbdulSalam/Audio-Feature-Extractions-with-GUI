cd /media/malik/New Volume/Projects/audio_feature_extraction/Audio_feauture_extrction
conda activate extractor
python feature_extractor_mic.py
