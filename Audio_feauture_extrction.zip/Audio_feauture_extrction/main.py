import sys
import os
from PyQt5 import QtGui, uic ,QtWidgets
from PyQt5.QtWidgets import QFileDialog
from subprocess import call
import glob
from shutil import copyfile
root = os.path.expanduser('~')
class MyWindow(QtWidgets.QDialog):
    def __init__(self):
        super(MyWindow, self).__init__()
        uic.loadUi('Malik_linker_dialog_base.ui', self)
        self.show()
        # self.setupUi(self)
        self.btn1.clicked.connect(self.ftn)
        self.btn2.clicked.connect(self.ftn2)
        self.browse_btn.clicked.connect(self.browse)

        # self.label.setText("Please select audio process Mode...")

    def browse(self):
        print("browse input ...")
        # to delete existing files from input directory
        files = glob.glob('./input_audio/*')
        for f in files:
            os.remove(f)
        # to popup browse window get name of file in fname veriable
        # filter = "Wav File (*.wav)"
        # fname = QFileDialog.getOpenFileName( "Audio File", "./", filter)
        fname = QFileDialog.getOpenFileNames(self, 'Open file', '/images/', 'Wav File (*.wav)')
        # print(len(fname))
        # print(fname)

        # self.filename.setText(fname[0])
        fname = fname[:-1]
        # print(fname,'/////////////////')
        len(fname)
        # fname= list(fname)
        # print(len(fname))
        for item in fname:
            print(item)
            for ind in item:
                print('This is index', ind)
                filename = os.path.basename(ind)
                print('file name is', filename)
                copyfile(ind, os.path.join("./input_audio",
                    filename))


        
    def ftn(self):
        # ammo = self.label_3.text()
        with open("./scripts/live.sh",
                'rb') as file:
            script = file.read()
        rc = call(script, shell=True)
        self.label.setText("created")
    def ftn2(self):
        self.label.setText("off line audio being processed...")

        with open("./scripts/offline.sh",
                'rb') as file:
            script = file.read()
        rc = call(script, shell=True)
        self.label.setText("off line executed")
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MyWindow()
    sys.exit(app.exec_())
